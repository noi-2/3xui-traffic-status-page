// force-push.js

// 引入所需模块
const  { exec : execCallback } = require('child_process');
const util = require("util");
const path = require("path");
// import util from 'util';
// import path from 'path';

// 将基于回调的 exec 转换为返回 Promise 的函数
const exec = util.promisify(execCallback);

// --- 配置区 ---
// ⚠️ 请务必修改为你的本地仓库路径！
const REPO_PATH = __dirname; 
const COMMIT_MESSAGE = `Automated commit: ${new Date().toISOString()}`;
const REMOTE_NAME = 'origin';
const BRANCH_NAME = 'main'; // 或者 'master'

/**
 * 封装一个执行命令的函数，统一处理日志和错误
 * @param {string} command - 要执行的命令
 * @param {string} cwd - 执行命令的工作目录
 */
async function executeCommand(command, cwd) {
  console.log(`\n▶️ Executing: ${command}`);
  try {
    const { stdout, stderr } = await exec(command, { cwd });
    if (stdout) console.log(`✅ STDOUT: \n${stdout}`);
    if (stderr) console.warn(`⚠️ STDERR: \n${stderr}`);
    return { success: true };
  } catch (error) {
    console.error(`❌ ERROR executing command: ${command}`);
    console.error(`Error Code: ${error.code}`);
    console.error(`Error Message: ${error.stderr || error.stdout}`);
    return { success: false };
  }
}

/**
 * 主函数，按顺序执行 Git 工作流
 */
module.exports = async function runGitWorkflow() {
  console.log(`🚀 Starting Git workflow for repository at: ${REPO_PATH}`);

  // 1. git add .
  if (!(await executeCommand('git add .', REPO_PATH)).success) {
    console.error('Failed at "git add". Aborting.');
    return;
  }

  // 2. git commit -m "..."
  // 注意：需要处理没有文件变更导致 commit 失败的情况
  const commitResult = await executeCommand(`git commit -m "${COMMIT_MESSAGE}"`, REPO_PATH);
  if (!commitResult.success && !commitResult.message?.includes("nothing to commit")) {
     // 如果不是因为"没东西提交"而失败，则中止
     console.error('Failed at "git commit". Aborting.');
     return;
  }

  // 3. git push --force-with-lease ...
  const pushCommand = `git push --force-with-lease ${REMOTE_NAME} ${BRANCH_NAME}`;
  if (!(await executeCommand(pushCommand, REPO_PATH)).success) {
    console.error('Failed at "git push". Aborting.');
    return;
  }

  console.log('\n🎉 Git workflow completed successfully!');
}

// 运行主函数
//runGitWorkflow();
