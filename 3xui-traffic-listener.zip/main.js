// 引入 sqlite 和 sqlite3
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const forcePushGithub = require("./force_push.js")
const validator = require("validator");
const dns2 = require("dns2")
const fastify = require('fastify')({ logger: true });
const fs_pms = require("fs").promises;
let db;
fastify.register(require("@fastify/cors"));
/* 

5.设计一个定时提交到github仓库的静态页面

9.
*/



async function get_hostname_dns_a(url){
  const url_parser = new URL(url);
  const _hostname = url_parser.hostname;
  if(validator.isIP(_hostname)){
    return _hostname;
  }
  const dns = new dns2({ 
      dns: '8.8.8.8' // 指定 DNS 服务器地址
  });
  try {
      // 查询 A 记录 (IPv4)
      const result = await dns.resolve(_hostname, 'A');
      const ip_list = (result.answers.map(ans => ans.address));
      if(ip_list.length === 0){
        return 'error'
      }
      return ip_list.slice(-1)[0];
  } catch (err) {
      console.error(err);
      return `error`;
  }
}

async function get_ip_location(ip){

  const res = await fetch(`https://mail.163.com/fgw/mailsrv-ipdetail/detail`,{
      headers:{
        'x-forwarded-for':ip,
        
      }
    });
    return await res.json();
}
async function get_3xui_traffic(panel_url,username,password){
//  var _data_obj = {
//       product_name:"nube.sh, de",
//       total:1024,
//       used:0,
//       ip:"205.198.91.40",
//       ip_location:"2.2.2.2"
//     }
    // const ip_result  = (await get_ip_location(_data_obj['ip']));
    // _data_obj['ip_location'] = `${ip_result['result']['country']} ${ip_result['result']['province']}`;
    // const ip_list = _data_obj['ip'].split(".");
    // _data_obj['ip'] = ip_list[0] + '.' +'*'.repeat(ip_list[1].length)  + '.'+ '*'.repeat(ip_list[2].length)  + '.'+ ( ip_list[3].length === 1 ?  '*' : '*'.repeat(ip_list[3].length-1)+ip_list[3].split("").slice(-1)[0]);
    
    // 3. 构建请求
    // 通常这种情况下，我们可能不需要带上原始请求的 header（因为 Host 不同），
    // 但需要加上 User-Agent 防止被目标拦截
    try{

  const newRequest = await fetch(`${panel_url}/login`, {
   
      headers: {
        "accept": "application/json, text/plain, */*",
    "accept-language": "zh-CN,zh;q=0.9",
    "cache-control": "no-cache",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    "pragma": "no-cache",
    "proxy-connection": "keep-alive",
    "x-requested-with": "XMLHttpRequest",
    "cookie": "lang=zh-CN",
    "Referer": `${panel_url}`,
       
        // 如果需要传递原始 body，可以在这里加上 body: request.body
      },
      "body": `username=${username}&password=${password}&twoFactorCode=`,
      "method": "POST"
    });
    const newRequest2 = await fetch(`${panel_url}/panel/api/inbounds/list`, {
      "headers": {
        "accept": "application/json, text/plain, */*",
        "accept-language": "zh-CN,zh;q=0.9",
        "cache-control": "no-cache",
        "pragma": "no-cache",
        "proxy-connection": "keep-alive",
        "x-requested-with": "XMLHttpRequest",
        "cookie": newRequest.headers.get("set-cookie"),
        "Referer": `${panel_url}/panel/inbounds`
      },
      "body": null,
      "method": "GET"
    });
    // console.log(await newRequest.text())
    const newRequest2_json = await newRequest2.json();
    // return JSON.stringify(newRequest2_json);
    if(newRequest2_json['success'] === true){
      // return new Response(modifiedText, { status: 200 });
      return ({
        total:newRequest2_json['obj'].reduce((total,v,k)=>{return total + Number((
        (v['total']/1024/1024/1024)
        ).toFixed(2))},0),
        used:newRequest2_json['obj'].reduce((total,v,k)=>{return total + Number((
        (v['up']/1024/1024/1024)+(v['down']/1024/1024/1024)
        ).toFixed(2))},0)
      })
      // _data_obj['used'] =  
    //    return new Response(`
    //    <svg xmlns="http://www.w3.org/2000/svg" width="467" height="195" viewBox="0 0 467 195" fill="none" role="img" aria-labelledby="descId">
    //            <title id="titleId"></title>
    //            <desc id="descId"></desc>
    //            <style>
    //              .header {
    //                font: 600 18px  Ubuntu, Sans-Serif;
    //                fill: #2f80ed;
    //                animation: fadeInAnimation 0.8s ease-in-out forwards;
    //              }
    //              @supports(-moz-appearance: auto) {
    //                /* Selector detects Firefox */
    //                .header { font-size: 15.5px; }
    //              }
                 
    //        .stat {
    //          font: 600 14px  Ubuntu, "Helvetica Neue", Sans-Serif; fill: #434d58;
    //        }
    //        @supports(-moz-appearance: auto) {
    //          /* Selector detects Firefox */
    //          .stat { font-size:12px; }
    //        }
    //        .stagger {
    //          opacity: 0;
    //          animation: fadeInAnimation 0.3s ease-in-out forwards;
    //        }
    //        .rank-text {
    //          font: 800 17px  Ubuntu, Sans-Serif; fill: #434d58;
    //          animation: scaleInAnimation 0.3s ease-in-out forwards;
    //        }
    //        .rank-percentile-header {
    //          font-size: 14px;
    //        }
    //        .rank-percentile-text {
    //          font-size: 16px;
    //        }
           
    //        .not_bold { font-weight: 400 }
    //        .bold { font-weight: 700 }
    //        .icon {
    //          fill: #4c71f2;
    //          display: block;
    //        }
       
    //        .rank-circle-rim {
    //          stroke: #2f80ed;
    //          fill: none;
    //          stroke-width: 6;
    //          opacity: 0.2;
    //        }
    //        .rank-circle {
    //          stroke: #2f80ed;
    //          stroke-dasharray: 250;
    //          fill: none;
    //          stroke-width: 6;
    //          stroke-linecap: round;
    //          opacity: 0.8;
    //          transform-origin: -10px 8px;
    //          transform: rotate(-90deg);
    //          animation: rankAnimation 1s forwards ease-in-out;
    //        }
           
    //        @keyframes rankAnimation {
    //          from {
    //            stroke-dashoffset: 251.32741228718345;
    //          }
    //          to {
    //            stroke-dashoffset: ${251.32741228718345 - 251.32741228718345*(_data_obj['used']/_data_obj['total'])};
    //          }
    //        }
         
         
       
                 
    //          /* Animations */
    //          @keyframes scaleInAnimation {
    //            from {
    //              transform: translate(-5px, 5px) scale(0);
    //            }
    //            to {
    //              transform: translate(-5px, 5px) scale(1);
    //            }
    //          }
    //          @keyframes fadeInAnimation {
    //            from {
    //              opacity: 0;
    //            }
    //            to {
    //              opacity: 1;
    //            }
    //          }
           
                 
    //            </style>
       
               
       
    //            <rect data-testid="card-bg" x="0.5" y="0.5" rx="4.5" height="99%" stroke="#e4e2e2" width="466" fill="#fffefe" stroke-opacity="1"/>
       
               
    //          <g data-testid="card-title" transform="translate(25, 35)">
    //            <g transform="translate(0, 0)">
    //          <text x="0" y="0" class="header" data-testid="header">${_data_obj['ip']} </text>
    //        </g>
    //          </g>
           
       
    //            <g data-testid="main-card-body" transform="translate(0, 55)">
                 
    //        <g data-testid="rank-circle" transform="translate(390.5, 34.5)">
    //            <circle class="rank-circle-rim" cx="-10" cy="8" r="40"/>
    //            <circle class="rank-circle" cx="-10" cy="8" r="40"/>
    //            <g class="rank-text">
                 
    //            <text x="-5" y="3" alignment-baseline="central" dominant-baseline="central" text-anchor="middle" data-testid="level-rank-icon">
    //              ${(_data_obj['used'] / _data_obj['total'] * 100).toFixed(1)}<tspan xmlns="http://www.w3.org/2000/svg" style="font-size: 14px;">%</tspan>
    //            </text>
             
    //            </g>
    //          </g>
    //        <svg x="0" y="0">
    //          <g transform="translate(0, 0)">
    //        <g class="stagger" style="animation-delay: 450ms" transform="translate(25, 0)">
             
    //        <svg data-testid="icon" class="icon" viewBox="0 0 16 16" version="1.1" width="16" height="16">
    //          <path fill-rule="evenodd" d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.194L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25zm0 2.445L6.615 5.5a.75.75 0 01-.564.41l-3.097.45 2.24 2.184a.75.75 0 01.216.664l-.528 3.084 2.769-1.456a.75.75 0 01.698 0l2.77 1.456-.53-3.084a.75.75 0 01.216-.664l2.24-2.183-3.096-.45a.75.75 0 01-.564-.41L8 2.694v.001z"/>
    //        </svg>
         
    //          <text class="stat  bold" x="25" y="12.5">产品</text>
    //          <text class="stat  bold" x="144.01" y="12.5" data-testid="stars">${_data_obj['product_name']}</text>
    //        </g>
    //      </g><g transform="translate(0, 25)">
    //        <g class="stagger" style="animation-delay: 600ms" transform="translate(25, 0)">
             
       
           
       
    //    <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="90 -860 960 960" width="20px" fill="#4c71f2"><path d="M480.28-96Q401-96 331-126t-122.5-82.5Q156-261 126-330.96t-30-149.5Q96-560 126-629.5q30-69.5 82.5-122T330.96-834q69.96-30 149.5-30t149.04 30q69.5 30 122 82.5T834-629.28q30 69.73 30 149Q864-401 834-331t-82.5 122.5Q699-156 629.28-126q-69.73 30-149 30Zm-.28-72q122 0 210-81t100-200q-9 8-20.5 12.5T744-432H600q-29.7 0-50.85-21.15Q528-474.3 528-504v-48H360v-96q0-29.7 21.15-50.85Q402.3-720 432-720h48v-24q0-14 5-26t13-21q-3-1-10-1h-8q-130 0-221 91t-91 221h216q60 0 102 42t42 102v48H384v105q23 8 46.73 11.5Q454.45-168 480-168Z"/></svg>
         
    //          <text class="stat  bold" x="25" y="12.5">地区</text>
    //          <text class="stat  bold" x="144.01" y="12.5" data-testid="commits">${_data_obj['ip_location']}</text>
    //        </g>
    //      </g><g transform="translate(0, 50)">
    //        <g class="stagger" style="animation-delay: 750ms" transform="translate(25, 0)">
             
    //        <svg data-testid="icon" class="icon" viewBox="0 0 16 16" version="1.1" width="16" height="16">
    //          <path fill-rule="evenodd" d="M7.177 3.073L9.573.677A.25.25 0 0110 .854v4.792a.25.25 0 01-.427.177L7.177 3.427a.25.25 0 010-.354zM3.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122v5.256a2.251 2.251 0 11-1.5 0V5.372A2.25 2.25 0 011.5 3.25zM11 2.5h-1V4h1a1 1 0 011 1v5.628a2.251 2.251 0 101.5 0V5A2.5 2.5 0 0011 2.5zm1 10.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0zM3.75 12a.75.75 0 100 1.5.75.75 0 000-1.5z"/>
    //        </svg>
         
    //          <text class="stat  bold" x="25" y="12.5">总流量</text>
    //          <text class="stat  bold" x="144.01" y="12.5" data-testid="prs">${_data_obj['total']} GB</text>
    //        </g>
    //      </g><g transform="translate(0, 75)">
    //        <g class="stagger" style="animation-delay: 900ms" transform="translate(25, 0)">
             
    //        <svg data-testid="icon" class="icon" viewBox="0 0 16 16" version="1.1" width="16" height="16">
    //          <path fill-rule="evenodd" d="M8 1.5a6.5 6.5 0 100 13 6.5 6.5 0 000-13zM0 8a8 8 0 1116 0A8 8 0 010 8zm9 3a1 1 0 11-2 0 1 1 0 012 0zm-.25-6.25a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z"/>
    //        </svg>
         
    //          <text class="stat  bold" x="25" y="12.5">已使用</text>
    //          <text class="stat  bold" x="144.01" y="12.5" data-testid="issues">${_data_obj['used'].toFixed(2)} GB</text>
    //        </g>
    //      </g>
    //        </svg>
         
    //            </g>
    //          </svg>`, {
    // headers:{
    //   "content-type":"image/svg+xml"
    // },
    //      status: 200 
    //     })
        
    }

    }catch(e){
      console.log(e.message);
      return 'error'
    }
  
}


async function edit(product_name,origin_panel_url,panel_url,username,password){
  const result = await db.run(`UPDATE panels_config_list SET product_name = :product_name, panel_url = :panel_url, username = :username, password = :password WHERE panel_url = :origin_panel_url`,{
    ':product_name':product_name,
    ':panel_url':panel_url,
    ':username':username,
    ':password':password,
    ':origin_panel_url':origin_panel_url
  });
  return result;
}

async function remove(panel_url){
  const result = await db.run(`DELETE FROM panels_config_list WHERE panel_url = :panel_url`,{
    ':panel_url':panel_url
  });
  return result;
}
async function add(product_name,panel_url,username,password){
  const _get_ip = await get_hostname_dns_a(panel_url);
  if(_get_ip === 'error'){return 'error'}
  const _get_ip_location = await get_ip_location(_get_ip);
  const _get_panel_info = await get_3xui_traffic(panel_url,username,password);
  if(_get_panel_info === 'error') {return 'error'}
    const result = await db.run(
      'INSERT INTO panels_config_list (product_name,panel_url,username,password,ip,ip_location,total,used,state) VALUES (:product_name, :panel_url, :username, :password, :ip, :ip_location, :total, :used, :state)',
      { ':product_name':product_name,':panel_url': panel_url, ':username': username,':password':password, ':ip':_get_ip, ':ip_location':`${_get_ip_location['result']['country']} ${_get_ip_location['result']['province'] === 'UNKNOWN' ? '' : _get_ip_location['result']['province']}`,
        ':total':`${_get_panel_info['total']}`,':used':`${_get_panel_info['used']}`,':state':'online'
       }
    );
    return result;
}

async function get_all(){
  const panels_config_list = await db.all('SELECT * FROM panels_config_list');
  return panels_config_list;
}
async function udpate_panel_list_info(){
  const _data = await get_all();
  for(let i of _data)    {
   if(i['panel_url']){
    const {total,used} = await get_3xui_traffic(i['panel_url'],i['username'],i['password']);
    await db.run(`UPDATE panels_config_list SET total = :total, used = :used WHERE panel_url = :panel_url;`,{
      ':panel_url':i['panel_url'],
      ':total':total,
      ':used':used,
    })
   }
  }
}
async function render_list_info_page(){
  const _data = await get_all();
  const rendered_html =  `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div style="padding:1vh 0; display: flex;justify-content:center;gap:1vh;flex-wrap: wrap;">
        
${_data.map(v=>{ 
  const ip_list = v['ip'].split(".");
  const format_ip = ((ip_list[0] - 34) <=0 ? 1: (ip_list[0]-34) ) + '.' +'*'.repeat(ip_list[1].length)  + '.'+ '*'.repeat(ip_list[2].length)  + '.'+ ( ip_list[3].length === 1 ?  '*' : '*'.repeat(ip_list[3].length-1)+ip_list[3].split("").slice(-1)[0]);
  return`<svg 
    style="box-shadow:0 2px 15px -3px rgba(0, 0, 0, 0.07), 0 10px 20px -2px rgba(0, 0, 0, 0.04);"
       xmlns="http://www.w3.org/2000/svg" width="467" height="195" viewBox="0 0 467 195" fill="none" role="img" aria-labelledby="descId">
               <title id="titleId"></title>
               <desc id="descId"></desc>
               <style>
                 .header {
                   font: 600 18px  Ubuntu, Sans-Serif;
                   fill: #2f80ed;
                   animation: fadeInAnimation 0.8s ease-in-out forwards;
                 }
                 @supports(-moz-appearance: auto) {
                   /* Selector detects Firefox */
                   .header { font-size: 15.5px; }
                 }
                 
           .stat {
             font: 600 14px  Ubuntu, "Helvetica Neue", Sans-Serif; fill: #434d58;
           }
           @supports(-moz-appearance: auto) {
             /* Selector detects Firefox */
             .stat { font-size:12px; }
           }
           .stagger {
             opacity: 0;
             animation: fadeInAnimation 0.3s ease-in-out forwards;
           }
           .rank-text {
             font: 800 17px  Ubuntu, Sans-Serif; fill: #434d58;
             animation: scaleInAnimation 0.3s ease-in-out forwards;
           }
           .rank-percentile-header {
             font-size: 14px;
           }
           .rank-percentile-text {
             font-size: 16px;
           }
           
           .not_bold { font-weight: 400 }
           .bold { font-weight: 700 }
           .icon {
             fill: #4c71f2;
             display: block;
           }
       
           .rank-circle-rim {
             stroke: #2f80ed;
             fill: none;
             stroke-width: 6;
             opacity: 0.2;
           }
           .rank-circle {
             stroke: #2f80ed;
             stroke-dasharray: 250;
             fill: none;
             stroke-width: 6;
             stroke-linecap: round;
             opacity: 0.8;
             transform-origin: -10px 8px;
             transform: rotate(-90deg);
             animation: rankAnimation 1s forwards ease-in-out;
           }
           
           @keyframes rankAnimation {
             from {
               stroke-dashoffset: 251.32741228718345;
             }
             to {
               stroke-dashoffset: ${251.32741228718345 - 251.32741228718345*(v['used']/v['total'])};
             }
           }
         
         
       
                 
             /* Animations */
             @keyframes scaleInAnimation {
               from {
                 transform: translate(-5px, 5px) scale(0);
               }
               to {
                 transform: translate(-5px, 5px) scale(1);
               }
             }
             @keyframes fadeInAnimation {
               from {
                 opacity: 0;
               }
               to {
                 opacity: 1;
               }
             }
           
                 
               </style>
       
               
       
               <rect data-testid="card-bg" x="0.5" y="0.5" rx="4.5" height="99%" stroke="#e4e2e2" width="466" fill="#fffefe" stroke-opacity="0"/>
       
               
             <g data-testid="card-title" transform="translate(25, 35)">
               <g transform="translate(0, 0)">
             <text x="0" y="0" class="header" data-testid="header">${format_ip} </text>
           </g>
             </g>
           
       
               <g data-testid="main-card-body" transform="translate(0, 55)">
                 
           <g data-testid="rank-circle" transform="translate(390.5, 34.5)">
               <circle class="rank-circle-rim" cx="-10" cy="8" r="40"/>
               <circle class="rank-circle" cx="-10" cy="8" r="40"/>
               <g class="rank-text">
                 
               <text x="-5" y="3" alignment-baseline="central" dominant-baseline="central" text-anchor="middle" data-testid="level-rank-icon">
                 ${(v['used'] / v['total'] * 100).toFixed(1)}<tspan xmlns="http://www.w3.org/2000/svg" style="font-size: 14px;">%</tspan>
               </text>
             
               </g>
             </g>
           <svg x="0" y="0">
             <g transform="translate(0, 0)">
           <g class="stagger" style="animation-delay: 450ms" transform="translate(25, 0)">
             
           <svg data-testid="icon" class="icon" viewBox="0 0 16 16" version="1.1" width="16" height="16">
             <path fill-rule="evenodd" d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.194L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25zm0 2.445L6.615 5.5a.75.75 0 01-.564.41l-3.097.45 2.24 2.184a.75.75 0 01.216.664l-.528 3.084 2.769-1.456a.75.75 0 01.698 0l2.77 1.456-.53-3.084a.75.75 0 01.216-.664l2.24-2.183-3.096-.45a.75.75 0 01-.564-.41L8 2.694v.001z"/>
           </svg>
         
             <text class="stat  bold" x="25" y="12.5">产品</text>
             <text class="stat  bold" x="144.01" y="12.5" data-testid="stars">${v['product_name']}</text>
           </g>
         </g><g transform="translate(0, 25)">
           <g class="stagger" style="animation-delay: 600ms" transform="translate(25, 0)">
             
       
           
       
       <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="90 -860 960 960" width="20px" fill="#4c71f2"><path d="M480.28-96Q401-96 331-126t-122.5-82.5Q156-261 126-330.96t-30-149.5Q96-560 126-629.5q30-69.5 82.5-122T330.96-834q69.96-30 149.5-30t149.04 30q69.5 30 122 82.5T834-629.28q30 69.73 30 149Q864-401 834-331t-82.5 122.5Q699-156 629.28-126q-69.73 30-149 30Zm-.28-72q122 0 210-81t100-200q-9 8-20.5 12.5T744-432H600q-29.7 0-50.85-21.15Q528-474.3 528-504v-48H360v-96q0-29.7 21.15-50.85Q402.3-720 432-720h48v-24q0-14 5-26t13-21q-3-1-10-1h-8q-130 0-221 91t-91 221h216q60 0 102 42t42 102v48H384v105q23 8 46.73 11.5Q454.45-168 480-168Z"/></svg>
         
             <text class="stat  bold" x="25" y="12.5">地区</text>
             <text class="stat  bold" x="144.01" y="12.5" data-testid="commits">${v['ip_location']}</text>
           </g>
         </g><g transform="translate(0, 50)">
           <g class="stagger" style="animation-delay: 750ms" transform="translate(25, 0)">
             
           <svg data-testid="icon" class="icon" viewBox="0 0 16 16" version="1.1" width="16" height="16">
             <path fill-rule="evenodd" d="M7.177 3.073L9.573.677A.25.25 0 0110 .854v4.792a.25.25 0 01-.427.177L7.177 3.427a.25.25 0 010-.354zM3.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122v5.256a2.251 2.251 0 11-1.5 0V5.372A2.25 2.25 0 011.5 3.25zM11 2.5h-1V4h1a1 1 0 011 1v5.628a2.251 2.251 0 101.5 0V5A2.5 2.5 0 0011 2.5zm1 10.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0zM3.75 12a.75.75 0 100 1.5.75.75 0 000-1.5z"/>
           </svg>
         
             <text class="stat  bold" x="25" y="12.5">总流量</text>
             <text class="stat  bold" x="144.01" y="12.5" data-testid="prs">${v['total']} GB</text>
           </g>
         </g><g transform="translate(0, 75)">
           <g class="stagger" style="animation-delay: 900ms" transform="translate(25, 0)">
             
           <svg data-testid="icon" class="icon" viewBox="0 0 16 16" version="1.1" width="16" height="16">
             <path fill-rule="evenodd" d="M8 1.5a6.5 6.5 0 100 13 6.5 6.5 0 000-13zM0 8a8 8 0 1116 0A8 8 0 010 8zm9 3a1 1 0 11-2 0 1 1 0 012 0zm-.25-6.25a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z"/>
           </svg>
         
             <text class="stat  bold" x="25" y="12.5">已使用</text>
             <text class="stat  bold" x="144.01" y="12.5" data-testid="issues">${v['used']} GB</text>
           </g>
         </g>
           </svg>
         
               </g>
             </svg>`}).join("\n")}
    </div>
    
    <div style="max-width: 200px; box-shadow:0 4px 9px -4px #000;position: fixed;right:1vh;bottom:2vh;padding:8px; border-radius:3px; display:flex; align-items: center; background-color: #000;flex-wrap: wrap;">    
        <img src="github.svg" style="width:24px;" />
        <span style="margin-left:8px;color: #fff;font-family: Ubuntu;letter-spacing: .2px;font-size:15px;">MHSanaei/3x-ui</span>
        <span style="flex-basis: 100%;color: #fff;font-size: 9px;text-align: right;margin-top: 5px;font-family: Ubuntu;letter-spacing: .2px; " >API data from </span>
    </div>
</body>
</html>`
await fs_pms.writeFile(`${__dirname}/index.html`,rendered_html);

}
fastify.get("/all",async function(req,rep){
  const _data = await get_all();
  return rep.send({msg:"",data:_data})
});

fastify.post('/add', async function  (request, reply) {
  const {product_name, panel_url,username,password} = request.body;
  if(! validator.isURL(panel_url) || !username || !password){

    reply.send({msg:"panel_url is not correctly"})
  }else{
     if(await add(product_name,panel_url,username,password) === 'error'){
      reply.send({msg:"error in add"});
     }else{
      render_list_info_page();
       reply.send({msg:'success'})
     }

  }
  reply.send({ hello: 'world' })
});


fastify.post("/edit",async function(req,rep){
  const {product_name, origin_panel_url,panel_url,username,password} = req.body;
  if(! validator.isURL(panel_url) || !username || !password || !origin_panel_url){
    rep.send({msg:"panel_url is not correctly"});
  };
  await edit(product_name, origin_panel_url,panel_url,username,password);
  rep.send({msg:"success"})
});



fastify.post("/delete",async function(req,rep){
  const {panel_url} = req.body;
  if(! validator.isURL(panel_url)){
    rep.send({msg:"panel_url is not correctly"});
  };
  await remove(panel_url);
  rep.send({msg:"success"})
});

// Run the server!
fastify.listen({ port: 3232 }, (err) => {
  if (err) {
    fastify.log.error(err)
    process.exit(1)
  }
})

// 建立一個 async 函式來執行所有操作


async function db_init() {
  try {
    // 1. 開啟資料庫
    db = await open({
      filename: `${__dirname}/data.db`,
      driver: sqlite3.Database
    });
    console.log('成功連接到 SQLite 資料庫。');

    // 2. 建立資料表 (如果不存在)
    await db.exec(`
      CREATE TABLE IF NOT EXISTS panels_config_list (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_name TEXT NOT NULL,
        panel_url TEXT NOT NULL,
        username TEXT NOT NULL,
        password TEXT NOT NULL,
        ip TEXT NOT NULL,
        ip_location TEXT NOT NULL,
        total TEXT NOT NULL,
        used TEXT NOT NULL,
        state TEXT NOT NULL
      )
    `);
    console.log('資料表 "panels_config_list" 已準備就緒。');

    // 3. 插入資
    // 料 (使用具名參數)
    // const result = await db.run(
    //   'INSERT INTO panels_config_list (name, price) VALUES (:name, :price)',
    //   { ':name': 'Laptop', ':price': 1200.50 }
    // );
    // console.log(`成功插入一筆商品，ID 為 ${result.lastID}`);

    // 4. 查詢所有資料
    // console.log('\n所有商品:');
    // panels_config_list.forEach(p => {
    //   console.log(`ID: ${p.id}, Name: ${p.name}, Price: $${p.price}`);
    // });

    // 5. 查詢單筆資料
    // const product = await db.get('SELECT * FROM panels_config_list WHERE id = ?', [1]);
    // if (product) {
    //   console.log(`\n找到 ID 為 1 的商品: ${product.name}`);
    // }

  } catch (err) {
    console.error('發生錯誤:', err.message);
  }
}
async function main(){
  await db_init();
  await udpate_panel_list_info();
await render_list_info_page();
forcePushGithub();
  // render_list_info_page();
  // udpate_panel_list_info();
}


setInterval(async ()=>{
await udpate_panel_list_info();
await render_list_info_page();
forcePushGithub();
},1000*60*30)

// 執行主函式
main();
/*     panel_url:"http://154.3.39.10:54321/Bz3hJReEgDhCwuK/",
    username:"gH8QtlCcBs",
    password:"nnz20sedBv", */
// get_3xui_traffic(
// "http://154.3.39.10:54321/Bz3hJReEgDhCwuK",
// "gH8QtlCcBs","nnz20sedBv").then(console.log)


const cleanup = () => {
    if (db) {
       db.close();
      console.log('\n資料庫連接已關閉。');
    }
  // 释放资源等
};

const signals = ['SIGINT', 'SIGTERM', 'SIGQUIT'];

signals.forEach(signal => {
  process.on(signal, () => {
    console.log(`Received ${signal}.`);
    cleanup();
    process.exit(0);
  });
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err);
  cleanup();
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled rejection at:', promise, 'reason:', reason);
  cleanup();
  process.exit(1);
});
